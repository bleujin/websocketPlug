package net.ion.websocket.common;

import net.ion.websocket.common.filter.BaseFilter;

public class MyFirstFilter extends BaseFilter {

	public MyFirstFilter(String aId) {
		super(aId);
	}

}
